module ActionView
  module Helpers
    module Tags # :nodoc:
      class EmailField < TextField # :nodoc:
      end
    end
  end
end
