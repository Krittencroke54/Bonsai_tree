module FooHelper
  redefine_method(:baz) {}
end
