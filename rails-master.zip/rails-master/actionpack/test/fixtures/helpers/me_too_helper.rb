module MeTooHelper
  def me() "me too!" end
end