module JustMeHelper
  def me() "mine!" end
end