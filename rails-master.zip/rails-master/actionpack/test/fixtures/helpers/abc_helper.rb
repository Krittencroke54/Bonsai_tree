module AbcHelper
  def bare_a() end
end
