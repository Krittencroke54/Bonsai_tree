module Fun
  module PdfHelper
    def foobar() 'baz' end
  end
end
