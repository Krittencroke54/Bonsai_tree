module Pack2Helper
  def conflicting_helper
    "pack2"
  end
end
