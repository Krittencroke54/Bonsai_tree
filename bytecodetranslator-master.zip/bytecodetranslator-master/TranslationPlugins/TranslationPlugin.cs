﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TranslationPlugins {
  public class TranslationPlugin {
    // TODO ideally these should really work as plugins, possibly registering as callbacks to some BCT events.
  }
}
