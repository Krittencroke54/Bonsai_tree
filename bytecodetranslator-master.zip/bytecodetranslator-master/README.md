# Bytecode Translator

This project implements a translator from .NET bytecode to Boogie
